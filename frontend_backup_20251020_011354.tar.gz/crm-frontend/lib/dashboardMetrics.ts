/**
 * Temporary dashboard metrics until real data sources are connected.
 * Keep values in sync across components that display high-level counts.
 */
export const DEFAULT_TODAY_TASKS_COUNT = 3
