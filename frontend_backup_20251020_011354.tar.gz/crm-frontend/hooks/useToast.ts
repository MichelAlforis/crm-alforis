// hooks/useToast.ts - Réexport du hook Toast
'use client'

export { useToast } from '@/components/ui/Toast'